Parameters
----------

* motif threshold: specificity of selected binding sites (in log2?).
	indentation?
* extent: shift allowed within alignments
* ...

### Sequence coordinates

For drosophila, coordinates are expected to be in Release 5 format.

Execution time
--------------

Running imogene can be long. For about 15 enhancers in the genmot mot, it takes in the order of a day. The scangen mode is faster: around one hour for completion.


Help
----

If you have any question concerning the interface or imogene in general please find us on [github](https://github.com/hrouault/Imogene) or send e-mail to:

* Hervé Rouault <herve.rouault@pasteur.fr>
* Marc Santolini <santolin@lps.ens.fr>
